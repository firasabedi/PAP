Persistence-Adaptive Purity (PAP) Windowing — Manuscript source package
Target venue: Multimedia Tools and Applications (Springer), Springer Nature sn-jnl template.

CONTENTS
  main_mtap.tex            Manuscript source (numbered sections, no TikZ dependency).
  sn-jnl.cls               Springer Nature journal class.
  sn-vancouver-num.bst     Numbered reference style (BibTeX).
  idea2_references.bib     Bibliography (BibTeX source).
  main_mtap.bbl            Pre-built bibliography (lets the paper compile without re-running BibTeX).
  figures/                 Vector PDF figures referenced by the manuscript.
                           fig_pipeline.pdf and fig_pap_flowchart.pdf are the two diagrams
                           that previously used TikZ; they are now generated images.
  scripts/make_flowcharts.py
                           Python/matplotlib script that generates the two flowchart figures
                           (fig_pipeline.pdf and fig_pap_flowchart.pdf).

COMPILE
  pdflatex main_mtap
  bibtex   main_mtap
  pdflatex main_mtap
  pdflatex main_mtap
  (Built and verified with MiKTeX; 29 pages.)

REFERENCE STYLE NOTE
  The paper uses sn-vancouver-num (a Springer Nature numbered style) because its .bst ships here
  and compiles out of the box. MTAP's documented style is the "Basic" numbered style; to switch,
  change the \documentclass option to sn-basic and add sn-basic.bst (from the official Springer
  Nature template) to this folder.

PLACEHOLDERS TO COMPLETE BEFORE SUBMISSION
  - Author names, affiliation, corresponding e-mail (title block).
  - [CPU] / [RAM] / [OS] in the Experimental Setup.
  - [REPOSITORY URL] in Code Availability.
  - Acknowledgements, Funding, Competing Interests confirmation, Author Contributions (CRediT).

NOT INCLUDED
  The experiment/analysis code (node-round structure recovery, persistence measurement,
  fixed/PAP windowing, the classifier runs, and the scripts that produced figures fig1-fig7
  and all tables) is NOT part of this package; it was not among the materials used to prepare
  this submission bundle.
