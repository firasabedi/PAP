#!/usr/bin/env python3
"""Generate the two flowchart figures (pipeline + PAP) that previously used TikZ.
Outputs vector PDF + PNG into the MTAP/figures folder. Self-contained matplotlib."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Polygon
import os

OUT = r"X:\Research\25-26\haider et al\Third paper\MTAP\figures"
os.makedirs(OUT, exist_ok=True)

plt.rcParams.update({
    "font.family": "serif",
    "font.size": 9,
    "text.usetex": False,
})

LINEW = 1.1
BOXKW = dict(boxstyle="round,pad=0.10,rounding_size=0.08",
             linewidth=LINEW, edgecolor="black", facecolor="white")


def box(ax, cx, cy, w, h, text, fc="white"):
    kw = dict(BOXKW)
    kw["facecolor"] = fc
    p = FancyBboxPatch((cx - w / 2, cy - h / 2), w, h, **kw)
    ax.add_patch(p)
    ax.text(cx, cy, text, ha="center", va="center", fontsize=9, zorder=5)
    return p


def diamond(ax, cx, cy, w, h, text, fc="white"):
    pts = [(cx, cy + h / 2), (cx + w / 2, cy), (cx, cy - h / 2), (cx - w / 2, cy)]
    poly = Polygon(pts, closed=True, linewidth=LINEW, edgecolor="black",
                   facecolor=fc, zorder=4)
    ax.add_patch(poly)
    ax.text(cx, cy, text, ha="center", va="center", fontsize=9, zorder=5)


def arrow(ax, xy_from, xy_to, connectionstyle="arc3,rad=0"):
    a = FancyArrowPatch(xy_from, xy_to, arrowstyle="-|>", mutation_scale=12,
                        linewidth=LINEW, color="black",
                        connectionstyle=connectionstyle,
                        shrinkA=1, shrinkB=1, zorder=3)
    ax.add_patch(a)


# ---------------------------------------------------------------------------
# Figure 1: study pipeline (snake layout, 7 stages)
# ---------------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(7.0, 3.1))
W, H = 1.9, 0.9
# columns x = 0, 2.4, 4.8 ; rows y = 3.0 (top), 1.5 (mid), 0.0 (bottom)
xcol = [0.0, 2.4, 4.8]
ytop, ymid, ybot = 3.0, 1.5, 0.0

# Row 1 (L->R): a, b, c
box(ax, xcol[0], ytop, W, H, "Data acquisition\n(WSN-DS)")
box(ax, xcol[1], ytop, W, H, "Structure\nrecovery")
box(ax, xcol[2], ytop, W, H, "Node-disjoint\nsplit")
# Row 2 (flow R->L): d (right), e (mid), f (left)
box(ax, xcol[2], ymid, W, H, "Persistence\nmeasurement")
box(ax, xcol[1], ymid, W, H, "Fixed / PAP\nwindowing")
box(ax, xcol[0], ymid, W, H, "Random forest")
# Row 3: g under f
box(ax, xcol[0], ybot, W, H, "Evaluation")

# arrows
arrow(ax, (xcol[0] + W / 2, ytop), (xcol[1] - W / 2, ytop))        # a->b
arrow(ax, (xcol[1] + W / 2, ytop), (xcol[2] - W / 2, ytop))        # b->c
arrow(ax, (xcol[2], ytop - H / 2), (xcol[2], ymid + H / 2))        # c->d (down)
arrow(ax, (xcol[2] - W / 2, ymid), (xcol[1] + W / 2, ymid))        # d->e (left)
arrow(ax, (xcol[1] - W / 2, ymid), (xcol[0] + W / 2, ymid))        # e->f (left)
arrow(ax, (xcol[0], ymid - H / 2), (xcol[0], ybot + H / 2))        # f->g (down)

ax.set_xlim(-1.2, 6.0)
ax.set_ylim(-0.7, 3.7)
ax.set_aspect("equal")
ax.axis("off")
fig.tight_layout(pad=0.2)
fig.savefig(os.path.join(OUT, "fig_pipeline.pdf"), bbox_inches="tight")
fig.savefig(os.path.join(OUT, "fig_pipeline.png"), dpi=300, bbox_inches="tight")
plt.close(fig)

# ---------------------------------------------------------------------------
# Figure 2: PAP flowchart
# ---------------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(7.0, 3.4))
W, H = 2.2, 0.95
xa, xb, xc = 0.0, 2.9, 5.8
ytop = 3.0
# top row
box(ax, xa, ytop, W, H, "Training\npartition")
box(ax, xb, ytop, W, H, r"Mean run length" + "\n" + r"$\bar{m}_c$ per attack class")
box(ax, xc, ytop, W + 0.3, H, r"Per-class threshold $\tau_c$;" + "\n" + r"$\tau_{\mathrm{Normal}}=\tau_{\mathrm{fixed}}$")
# candidate window (below left)
yd = 1.0
box(ax, xa, yd, W + 0.3, H, "Candidate window:\nlabel $y$, purity $p$")
# decision diamond
xe = 2.9
diamond(ax, xe, yd, 2.0, 1.25, r"$p \geq \tau_y$?")
# retain / discard
xf = 5.6
off = 0.75
box(ax, xf, yd + off, 1.9, 0.8, "Retain\nwindow")
box(ax, xf, yd - off, 1.9, 0.8, "Discard\nwindow")

# arrows top row
arrow(ax, (xa + W / 2, ytop), (xb - W / 2, ytop))
arrow(ax, (xb + W / 2, ytop), (xc - (W + 0.3) / 2, ytop))
# c down and back to candidate window top (explicit L-route, clears retain box)
ylane = 2.4
ax.plot([xc, xc, xa], [ytop - H / 2, ylane, ylane],
        color="black", linewidth=LINEW, zorder=3, solid_capstyle="round")
arrow(ax, (xa, ylane), (xa, yd + H / 2))
# candidate -> decision
arrow(ax, (xa + (W + 0.3) / 2, yd), (xe - 1.0, yd))
# decision -> retain (yes)
arrow(ax, (xe + 1.0, yd), (xf - 1.9 / 2, yd + off),
      connectionstyle="arc3,rad=-0.25")
ax.text(xe + 1.25, yd + 0.5, "yes", fontsize=8.5, ha="left", va="center")
# decision -> discard (no)
arrow(ax, (xe + 1.0, yd), (xf - 1.9 / 2, yd - off),
      connectionstyle="arc3,rad=0.25")
ax.text(xe + 1.25, yd - 0.5, "no", fontsize=8.5, ha="left", va="center")

ax.set_xlim(-1.4, 7.4)
ax.set_ylim(-0.6, 3.7)
ax.set_aspect("equal")
ax.axis("off")
fig.tight_layout(pad=0.2)
fig.savefig(os.path.join(OUT, "fig_pap_flowchart.pdf"), bbox_inches="tight")
fig.savefig(os.path.join(OUT, "fig_pap_flowchart.png"), dpi=300, bbox_inches="tight")
plt.close(fig)

print("Wrote:")
for f in ("fig_pipeline.pdf", "fig_pipeline.png", "fig_pap_flowchart.pdf", "fig_pap_flowchart.png"):
    p = os.path.join(OUT, f)
    print(" ", f, os.path.getsize(p), "bytes")
